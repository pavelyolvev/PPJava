import java.util.ArrayList;

public interface CollectionMethods {
    String getTitle();
    int getCreditsDuration();
    int getShowDuration(int index);
    ArrayList<Integer> getDuration();
    int avgShowLength();
}
